ML Package
A simple Python package for building machine learning models for classification and regression tasks.

Installation
Install via pip:
pip install ml_package-0.1.0.tar.gz

Usage
from ml_package import question2

# Generate a dataset
X, y = question2.generate("classification", n_samples=100, n_features=5)

# Compute statistics
stats = question2.statistics(X, y)

# Train a model
model, error = question2.learn("classification", X, y)

# Make predictions
predictions = question2.predict(model, "classification")

Dependencies
numpy
scikit-learn
matplotlib
plotly


